<?php
if ( !defined( 'ABSPATH' ) ) { exit; }

if(!class_exists("AEAFEAdminMenu")) {
	class AEAFEAdminMenu {
		public function __construct() {
			add_action( 'admin_menu', [ $this, 'aeafeAdminMenu' ] );
			add_action( 'admin_enqueue_scripts', [$this, 'aeafeAdminEnqueueScripts'] );
			add_action('wp_ajax_bptbGetBlocks', [ $this, 'aeafeGetBlocks' ]);
			add_action('admin_head', [ $this, 'aeafeIconImgSizeStyle' ]);
		}

		public function aeafeIconImgSizeStyle() {
			$screen = get_current_screen();
				echo '
				<style>
					#toplevel_page_all-embed-addons-for-elementor .wp-menu-image img {
						width: 20px !important;
						height: 20px !important;
						object-fit: contain;
					}
				</style>';
		}
	
		public function aeafeAdminMenu() {
			// $menuIcon = '<svg viewBox="-1.26 0 70 70" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:cc="http://creativecommons.org/ns#" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns="http://www.w3.org/2000/svg" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <metadata> <rdf:rdf> <cc:work> <dc:subject> Code </dc:subject> <dc:identifier> code-file </dc:identifier> <dc:title> Code File </dc:title> <dc:format> image/svg+xml </dc:format> <dc:publisher> Amido Limited </dc:publisher> <dc:creator> Richard Slater </dc:creator> <dc:type rdf:resource="http://purl.org/dc/dcmitype/StillImage"></dc:type> </cc:work> </rdf:rdf> </metadata> <path d="m -99.01584,570.83675 c -3.17264,-0.83123 -5.72847,-3.33808 -6.6453,-6.51797 l -0.31664,-1.0982 0,-27.04305 c 0,-22.20209 0.0331,-27.17821 0.18483,-27.79807 0.10166,-0.41525 0.46444,-1.34185 0.80619,-2.05911 0.53117,-1.11483 0.79324,-1.47372 1.80565,-2.47272 1.3546,-1.33668 2.55993,-2.0244 4.32924,-2.47015 1.06307,-0.26783 1.55942,-0.27346 23.67983,-0.26872 l 22.594,0.005 7.0428,6.96184 7.0428,6.96184 -0.0418,24.22893 -0.0418,24.22893 -0.3245,0.96092 c -1.11816,3.31113 -3.48791,5.56775 -6.71307,6.39261 -1.00711,0.25758 -1.77491,0.26498 -26.71957,0.25764 -24.81831,-0.007 -25.71633,-0.0164 -26.68265,-0.26955 z m 52.72739,-5.81192 c 0.91283,-0.44823 1.63615,-1.31556 1.87019,-2.24254 0.0992,-0.39302 0.14532,-7.522 0.14532,-22.47714 l 0,-21.90158 -5.59393,-0.0359 -5.59393,-0.0359 -0.0358,-5.73121 -0.0358,-5.73121 -20.96716,10e-4 -20.96716,0.001 -0.68637,0.3203 c -0.3775,0.17617 -0.91454,0.57341 -1.1934,0.88277 -1.00274,1.11235 -0.93435,-0.93979 -0.93435,28.03679 0,28.12625 -0.0363,26.70391 0.71059,27.80828 0.41847,0.61872 1.20418,1.15671 2.00639,1.3738 0.51402,0.1391 5.74384,0.16956 25.56154,0.14889 l 24.9153,-0.026 0.79862,-0.39215 z m -33.58527,-10.52771 c -2.07448,-0.34818 -3.85541,-1.28358 -4.60848,-2.42051 -1.03081,-1.55623 -1.24495,-2.77747 -1.24737,-7.11352 -9.6e-4,-1.81202 -0.0613,-3.65769 -0.13397,-4.10149 -0.26208,-1.60032 -1.06953,-2.51537 -2.35842,-2.67267 l -0.7338,-0.0896 0,-1.99048 0,-1.99048 0.72272,-0.0882 c 0.96215,-0.11743 1.61069,-0.62298 2.06925,-1.61304 0.35217,-0.76034 0.35757,-0.82135 0.4449,-5.02519 0.0969,-4.66462 0.17189,-5.17713 0.97897,-6.69138 0.98381,-1.84581 3.12129,-2.8581 6.50415,-3.08031 l 1.29152,-0.0848 0,2.00496 0,2.00496 -0.51478,0.0864 c -1.34755,0.22622 -1.92878,0.58528 -2.40112,1.48334 -0.27967,0.53174 -0.30621,0.82651 -0.39126,4.34548 -0.0962,3.98223 -0.22748,4.96729 -0.83601,6.27496 -0.3246,0.69753 -1.56109,2.01727 -2.02923,2.16585 -0.39839,0.12644 -0.34602,0.22272 0.38004,0.69853 1.9389,1.27065 2.48674,3.20727 2.49424,8.81714 0.004,2.94207 0.11288,3.60717 0.70946,4.33093 0.41997,0.5095 1.39165,0.91197 2.20176,0.91197 l 0.3869,0 0,1.99047 0,1.99048 -1.13251,-0.0161 c -0.62288,-0.009 -1.43151,-0.0663 -1.79696,-0.12767 z m 10.06774,-1.84667 0,-1.99047 0.38691,0 c 0.63986,0 1.73822,-0.38637 2.04172,-0.71821 0.75038,-0.82048 0.78105,-1.00164 0.87767,-5.18459 0.095,-4.11199 0.19695,-4.92132 0.77574,-6.15729 0.44884,-0.95846 1.02167,-1.59742 1.86271,-2.07776 l 0.68106,-0.38897 -0.5331,-0.27505 c -1.13501,-0.58561 -1.99911,-1.84602 -2.4632,-3.5929 -0.18497,-0.69624 -0.25537,-1.73679 -0.32046,-4.73597 -0.0818,-3.76983 -0.09,-3.85545 -0.42644,-4.4561 -0.43586,-0.77815 -1.05013,-1.19054 -2.07315,-1.39181 l -0.80946,-0.15925 0,-1.99325 0,-1.99325 1.34685,0.0883 c 1.61808,0.10604 3.14128,0.47567 4.2347,1.02763 0.93228,0.47061 2.01042,1.55758 2.38512,2.40465 0.63579,1.4373 0.71164,2.04496 0.80797,6.47312 0.0788,3.62111 0.12851,4.33736 0.33358,4.8046 0.46963,1.07 1.35555,1.71593 2.35345,1.71593 l 0.48854,0 -0.038,2.02326 -0.038,2.02326 -0.63535,0.0907 c -0.80056,0.11433 -1.07486,0.26234 -1.60496,0.8661 -0.74099,0.84395 -0.84825,1.51108 -0.84934,5.28284 -10e-4,5.04322 -0.34069,6.72253 -1.64669,8.1515 -0.40374,0.44176 -1.01069,0.90447 -1.53651,1.17136 -1.05998,0.53802 -3.09591,0.97788 -4.53751,0.98032 l -1.06388,0.002 0,-1.99048 z" fill="#00bcf2" transform="translate(105.978 -501.108)"></path> </g></svg>';
	
			$menu_icon = plugins_url( 'assets/img/dashicon.png', __FILE__ );
			
			add_menu_page(
				__( 'All Embed Addons by bPlugins', 'allembed' ),
				__( 'All Embed Addons', 'allembed' ),
				'manage_options',
				'all-embed-addons-for-elementor',
				'',
				$menu_icon,
				22
			);
	
			add_submenu_page(
				'all-embed-addons-for-elementor',
				__('Dashboard - All Embed Addons by bPlugins', 'allembed'),
				__('Dashboard', 'allembed'),
				'manage_options',
				'all-embed-addons-for-elementor',
				[$this, 'aeafeRenderDashboardPage'],
				0
			);
		}

		public function aeafeGetBlocks(){
			$nonce = sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) ?? null;

			if( !wp_verify_nonce( $nonce, 'bptb_admin_nonce' )){
				wp_send_json_error( 'Invalid Request' );
			}

			$data = json_decode( stripslashes( $_POST['data'] ), true );
			$db_data = get_option( 'aeafeGetBlocks', [] );

			if( !isset( $data ) && $db_data ){
				wp_send_json_success( $db_data );
			}

			update_option( 'aeafeGetBlocks', $data );
			wp_send_json_success( $data );

		}
	
		public function aeafeRenderDashboardPage(){ ?>
			<div
				id='mpafebDashboard'
				data-info='<?php echo esc_attr( wp_json_encode( [
					'version' => AEAFE_VERSION,
					'nonce' => wp_create_nonce( 'bptb_admin_nonce' ),
					// 'isPremium' => aeafeIsPremium(),
					'isPremium' => true,
					'hasPro' => false,
					'action' => 'bptbGetBlocks'
				] ) ); ?>'
			></div>
		<?php }
	
		function aeafeAdminEnqueueScripts( $hook ) {
			if( strpos( $hook, 'all-embed-addons-for-elementor' ) ){
				wp_enqueue_style( 'aeafe-admin-dashboard', AEAFE_DIR_URL . 'build/admin/dashboard.css', [], AEAFE_VERSION );
				wp_enqueue_script( 'aeafe-admin-dashboard', AEAFE_DIR_URL . 'build/admin/dashboard.js', [ 'react', 'react-dom','wp-util' ], AEAFE_VERSION, true );
				wp_set_script_translations( 'aeafe-admin-dashboard', 'media-player-addons-for-elementor', AEAFE_DIR_PATH . 'languages' );
			}
		}
	}
	new AEAFEAdminMenu();
}
