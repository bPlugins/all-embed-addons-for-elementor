<?php
if ( !defined( 'ABSPATH' ) ) { exit; }

if(!class_exists("AEAFEAdminMenu")) {
	class AEAFEAdminMenu {
		public function __construct() {
			add_action( 'admin_menu', [ $this, 'aeafeAdminMenu' ] );
			add_action( 'admin_enqueue_scripts', [$this, 'aeafeAdminEnqueueScripts'] );
			add_action('wp_ajax_bptbGetBlocks', [ $this, 'aeafeGetBlocks' ]);
			add_action('admin_head', [ $this, 'aeafeIconImgSizeStyle' ]);
			add_action( 'admin_init', [ $this, 'save_google_photos_settings' ] );
		}

		public function aeafeIconImgSizeStyle() {
			$screen = get_current_screen();
				echo '
				<style>
					#toplevel_page_all-embed-addons-for-elementor .wp-menu-image img {
						width: 20px !important;
						height: 20px !important;
						object-fit: contain;
					}
				</style>';
		}
	
		public function aeafeAdminMenu() {
			
			$menu_icon = plugins_url( 'assets/img/dashicon.png', __FILE__ );
			
			add_menu_page(
				__( 'All Embed Addons by bPlugins', 'allembed' ),
				__( 'All Embed Addons', 'allembed' ),
				'manage_options',
				'all-embed-addons-for-elementor',
				'',
				$menu_icon,
				22
			);
	
			add_submenu_page(
				'all-embed-addons-for-elementor',
				__('Dashboard - All Embed Addons by bPlugins', 'allembed'),
				__('Dashboard', 'allembed'),
				'manage_options',
				'all-embed-addons-for-elementor',
				[$this, 'aeafeRenderDashboardPage'],
				0
			);

			add_submenu_page(
				'all-embed-addons-for-elementor',
				__('API Credentials - All Embed Addons', 'allembed'),
				__('API Credentials', 'allembed'),
				'manage_options',
				'aeafe-google-photos',
				[$this, 'render_google_photos_settings_page'],
				10
			);
		}

		public function save_google_photos_settings() {
			if ( ! isset( $_POST['aeafe_gphoto_save'] ) ) {
				return;
			}

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'Permission denied.', 'allembed' ) );
			}

			if ( ! isset( $_POST['aeafe_gphoto_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['aeafe_gphoto_nonce'] ) ), 'aeafe_gphoto_save_settings' ) ) {
				wp_die( esc_html__( 'Nonce verification failed.', 'allembed' ) );
			}

			$client_id = isset( $_POST['client_id'] ) ? sanitize_text_field( wp_unslash( $_POST['client_id'] ) ) : '';
			$client_secret = isset( $_POST['client_secret'] ) ? sanitize_text_field( wp_unslash( $_POST['client_secret'] ) ) : '';

			$settings = [
				'client_id'          => $client_id,
				'client_secret'      => $client_secret,
			];

			$api = AEAFE_Google_Photos_API::instance();
			$api->save_settings( $settings );

			wp_safe_redirect( admin_url( 'admin.php?page=aeafe-google-photos&saved=1' ) );
			exit;
		}

		public function render_google_photos_settings_page() {
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'allembed' ) );
			}

			$api = AEAFE_Google_Photos_API::instance();
			$settings = $api->get_settings();

			$client_id = isset( $settings['client_id'] ) ? $settings['client_id'] : '';
			$client_secret = isset( $settings['client_secret'] ) ? $settings['client_secret'] : '';
			$is_connected = $api->is_connected();
			$has_creds = $api->has_credentials();
			$oauth_url = $api->get_oauth_url();
			$redirect_uri = $api->get_redirect_uri();

			?>
			<div class="wrap aeafe-admin-wrap">
				<div class="aeafe-header">
					<div class="aeafe-header-left">
						<h1><?php esc_html_e( 'API Credentials', 'allembed' ); ?></h1>
						<p class="aeafe-header-desc"><?php esc_html_e( 'Manage external API connections and credentials for All Embed Addons widgets.', 'allembed' ); ?></p>
					</div>
				</div>

				<?php if ( isset( $_GET['saved'] ) ) : ?>
					<div class="notice notice-success is-dismissible">
						<p><?php esc_html_e( 'API Credentials saved successfully.', 'allembed' ); ?></p>
					</div>
				<?php endif; ?>

				<?php if ( isset( $_GET['connected'] ) ) : ?>
					<div class="notice notice-success is-dismissible">
						<p><?php esc_html_e( 'Successfully connected to Google Photos!', 'allembed' ); ?></p>
					</div>
				<?php endif; ?>

				<div class="aeafe-cards-grid">
					<!-- Main Settings Card -->
					<div class="aeafe-card">
						<div class="aeafe-card-header">
							<div class="aeafe-card-title-wrap">
								<span class="aeafe-service-icon google-photos-icon">
									<svg viewBox="0 0 24 24" width="24" height="24">
										<path d="M12 0C8.74 0 6.5 3.075 6.5 6.5h5.25v5.25H6.5C6.5 14.925 8.74 18 12 18V0z" fill="#F04231"/>
										<path d="M24 12c0-3.26-3.075-5.5-6.5-5.5v5.25h-5.25V6.5C9.075 6.5 6 8.74 6 12h18z" fill="#1977F2"/>
										<path d="M12 24c3.26 0 5.5-3.075 5.5-6.5h-5.25v-5.25H17.5c0 3.175-2.24 5.5-5.5 5.5V24z" fill="#30A952"/>
										<path d="M0 12c0 3.26 3.075 5.5 6.5 5.5v-5.25h5.25V17.5C8.575 17.5 6 15.26 6 12H0z" fill="#FFBD00"/>
									</svg>
								</span>
								<div>
									<h2><?php esc_html_e( 'Google Photos API', 'allembed' ); ?></h2>
									<span class="aeafe-card-subtitle"><?php esc_html_e( 'Used by the "Gallery for Google Photos" Elementor widget', 'allembed' ); ?></span>
								</div>
							</div>
							<div class="aeafe-status-badge <?php echo $is_connected ? 'status-connected' : ( $has_creds ? 'status-ready' : 'status-unconfigured' ); ?>">
								<span class="status-dot"></span>
								<span class="status-label">
									<?php
									if ( $is_connected ) {
										esc_html_e( 'Connected', 'allembed' );
									} elseif ( $has_creds ) {
										esc_html_e( 'Ready to Connect', 'allembed' );
									} else {
										esc_html_e( 'Not Configured', 'allembed' );
									}
									?>
								</span>
							</div>
						</div>

						<div class="aeafe-card-body">
							<form method="post" action="">
								<?php wp_nonce_field( 'aeafe_gphoto_save_settings', 'aeafe_gphoto_nonce' ); ?>

								<div class="aeafe-form-group">
									<label class="aeafe-label"><?php esc_html_e( 'Authorized Redirect URI', 'allembed' ); ?></label>
									<p class="aeafe-field-help">
										<?php esc_html_e( 'Add this exact URI to your Google Cloud Console OAuth 2.0 Client credentials under "Authorized redirect URIs":', 'allembed' ); ?>
									</p>
									<div class="aeafe-copy-box">
										<input type="text" id="aeafe-redirect-uri-input" readonly value="<?php echo esc_url( $redirect_uri ); ?>" class="aeafe-readonly-input" />
										<button type="button" id="aeafe-copy-uri-btn" class="button button-secondary">
											<span class="dashicons dashicons-admin-page"></span> <?php esc_html_e( 'Copy URI', 'allembed' ); ?>
										</button>
									</div>
								</div>

								<div class="aeafe-form-group">
									<label for="client_id" class="aeafe-label"><?php esc_html_e( 'OAuth Client ID', 'allembed' ); ?> <span class="required">*</span></label>
									<input type="text" id="client_id" name="client_id" value="<?php echo esc_attr( $client_id ); ?>" class="regular-text aeafe-input-full" placeholder="<?php esc_attr_e( 'xxxxxxxxxxxx.apps.googleusercontent.com', 'allembed' ); ?>" required />
								</div>

								<div class="aeafe-form-group">
									<label for="client_secret" class="aeafe-label"><?php esc_html_e( 'OAuth Client Secret', 'allembed' ); ?> <span class="required">*</span></label>
									<div class="aeafe-password-wrap">
										<input type="password" id="client_secret" name="client_secret" value="<?php echo esc_attr( $client_secret ); ?>" class="regular-text aeafe-input-full" placeholder="<?php esc_attr_e( 'Your OAuth Client Secret', 'allembed' ); ?>" required />
										<button type="button" class="aeafe-toggle-secret" title="<?php esc_attr_e( 'Show/Hide Secret', 'allembed' ); ?>">
											<span class="dashicons dashicons-visibility"></span>
										</button>
									</div>
								</div>

								<div class="aeafe-form-actions">
									<button type="submit" name="aeafe_gphoto_save" class="button button-primary button-large">
										<?php esc_html_e( 'Save Credentials', 'allembed' ); ?>
									</button>

									<?php if ( $is_connected ) : ?>
										<button type="button" id="aeafe-gphoto-disconnect" class="button button-secondary button-large aeafe-btn-danger">
											<?php esc_html_e( 'Disconnect Account', 'allembed' ); ?>
										</button>
										<button type="button" id="aeafe-gphoto-clear-cache" class="button button-secondary button-large">
											<span class="dashicons dashicons-update"></span> <?php esc_html_e( 'Clear Cache', 'allembed' ); ?>
										</button>
									<?php elseif ( $oauth_url ) : ?>
										<a href="<?php echo esc_url( $oauth_url ); ?>" class="button button-primary button-large aeafe-btn-connect">
											<span class="dashicons dashicons-admin-links"></span> <?php esc_html_e( 'Connect with Google Photos', 'allembed' ); ?>
										</a>
									<?php endif; ?>
								</div>
							</form>
						</div>
					</div>

					<!-- Instructions Card -->
					<div class="aeafe-card aeafe-guide-card">
						<div class="aeafe-card-header">
							<h2><?php esc_html_e( 'How to Get Google Photos API Credentials', 'allembed' ); ?></h2>
						</div>
						<div class="aeafe-card-body">
							<ol class="aeafe-steps-list">
								<li>
									<strong><?php esc_html_e( 'Open Google Cloud Console:', 'allembed' ); ?></strong>
									<span>
										<?php
										printf(
											esc_html__( 'Visit the %1$sGoogle Cloud Console%2$s and create a new project (or select an existing one).', 'allembed' ),
											'<a href="https://console.cloud.google.com/" target="_blank" rel="noopener noreferrer">',
											'</a>'
										);
										?>
									</span>
								</li>
								<li>
									<strong><?php esc_html_e( 'Enable Photos Library API:', 'allembed' ); ?></strong>
									<span><?php esc_html_e( 'Go to "APIs & Services" → "Library", search for "Photos Library API", and click "Enable".', 'allembed' ); ?></span>
								</li>
								<li>
									<strong><?php esc_html_e( 'Configure OAuth Consent Screen:', 'allembed' ); ?></strong>
									<span><?php esc_html_e( 'Go to "APIs & Services" → "OAuth consent screen", choose "External", enter your App Name and Email, and add your Google account as a Test User.', 'allembed' ); ?></span>
								</li>
								<li>
									<strong><?php esc_html_e( 'Create OAuth 2.0 Client ID:', 'allembed' ); ?></strong>
									<span><?php esc_html_e( 'Go to "APIs & Services" → "Credentials" → "Create Credentials" → "OAuth client ID". Select "Web application" as the Application type.', 'allembed' ); ?></span>
								</li>
								<li>
									<strong><?php esc_html_e( 'Add Authorized Redirect URI:', 'allembed' ); ?></strong>
									<span><?php esc_html_e( 'Copy the Redirect URI from the box on the left and paste it under "Authorized redirect URIs" in your Google Cloud credentials settings.', 'allembed' ); ?></span>
								</li>
								<li>
									<strong><?php esc_html_e( 'Save & Connect:', 'allembed' ); ?></strong>
									<span><?php esc_html_e( 'Copy your Client ID and Client Secret, paste them on the left, click "Save Credentials", and then click "Connect with Google Photos".', 'allembed' ); ?></span>
								</li>
							</ol>

							<div class="aeafe-help-footer">
								<p>
									<span class="dashicons dashicons-info"></span>
									<?php esc_html_e( 'Once connected, you can add the "Gallery for Google Photos" widget to any Elementor page and select your albums directly in the widget setting panel.', 'allembed' ); ?>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>

			<script type="text/javascript">
			jQuery(document).ready(function($) {
				// Copy URI Button
				$('#aeafe-copy-uri-btn').on('click', function(e) {
					e.preventDefault();
					var copyText = document.getElementById('aeafe-redirect-uri-input');
					copyText.select();
					copyText.setSelectionRange(0, 99999);
					navigator.clipboard.writeText(copyText.value).then(function() {
						var $btn = $('#aeafe-copy-uri-btn');
						var originalHtml = $btn.html();
						$btn.html('<span class="dashicons dashicons-yes"></span> <?php echo esc_js( __( 'Copied!', 'allembed' ) ); ?>');
						setTimeout(function() {
							$btn.html(originalHtml);
						}, 2000);
					});
				});

				// Toggle Password Visibility
				$('.aeafe-toggle-secret').on('click', function(e) {
					e.preventDefault();
					var $input = $('#client_secret');
					var $icon = $(this).find('.dashicons');
					if ($input.attr('type') === 'password') {
						$input.attr('type', 'text');
						$icon.removeClass('dashicons-visibility').addClass('dashicons-hidden');
					} else {
						$input.attr('type', 'password');
						$icon.removeClass('dashicons-hidden').addClass('dashicons-visibility');
					}
				});

				// Disconnect Action
				$('#aeafe-gphoto-disconnect').on('click', function(e) {
					e.preventDefault();
					if (!confirm('<?php echo esc_js( __( 'Are you sure you want to disconnect from Google Photos?', 'allembed' ) ); ?>')) return;

					var $btn = $(this);
					$btn.prop('disabled', true).text('<?php echo esc_js( __( 'Disconnecting...', 'allembed' ) ); ?>');

					$.post(ajaxurl, {
						action: 'aeafe_gphoto_disconnect',
						nonce: '<?php echo esc_js( wp_create_nonce( 'aeafe_gphoto_nonce' ) ); ?>'
					}, function(response) {
						if (response.success) {
							location.reload();
						} else {
							alert(response.data);
							$btn.prop('disabled', false).text('<?php echo esc_js( __( 'Disconnect Account', 'allembed' ) ); ?>');
						}
					});
				});

				// Clear Cache Action
				$('#aeafe-gphoto-clear-cache').on('click', function(e) {
					e.preventDefault();
					var $btn = $(this);
					var originalText = $btn.html();
					$btn.prop('disabled', true).text('<?php echo esc_js( __( 'Clearing...', 'allembed' ) ); ?>');

					$.post(ajaxurl, {
						action: 'aeafe_gphoto_clear_cache',
						nonce: '<?php echo esc_js( wp_create_nonce( 'aeafe_gphoto_nonce' ) ); ?>'
					}, function(response) {
						alert(response.data);
						$btn.prop('disabled', false).html(originalText);
					});
				});
			});
			</script>

			<style type="text/css">
			.aeafe-admin-wrap {
				max-width: 1200px;
				margin-top: 20px;
				font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
			}
			.aeafe-header {
				margin-bottom: 25px;
			}
			.aeafe-header h1 {
				font-size: 26px;
				font-weight: 700;
				color: #1d2327;
				margin: 0 0 6px 0;
			}
			.aeafe-header-desc {
				font-size: 14px;
				color: #646970;
				margin: 0;
			}
			.aeafe-cards-grid {
				display: grid;
				grid-template-columns: 1.2fr 1fr;
				gap: 24px;
				align-items: start;
			}
			@media (max-width: 960px) {
				.aeafe-cards-grid {
					grid-template-columns: 1fr;
				}
			}
			.aeafe-card {
				background: #ffffff;
				border: 1px solid #dcdcde;
				border-radius: 8px;
				box-shadow: 0 1px 3px rgba(0,0,0,0.05);
				overflow: hidden;
			}
			.aeafe-card-header {
				padding: 20px 24px;
				border-bottom: 1px solid #f0f0f1;
				display: flex;
				align-items: center;
				justify-content: space-between;
			}
			.aeafe-card-title-wrap {
				display: flex;
				align-items: center;
				gap: 14px;
			}
			.aeafe-service-icon {
				display: flex;
				align-items: center;
				justify-content: center;
				width: 40px;
				height: 40px;
				background: #f6f7f7;
				border-radius: 8px;
			}
			.aeafe-card-header h2 {
				font-size: 18px;
				font-weight: 600;
				margin: 0;
				color: #1d2327;
			}
			.aeafe-card-subtitle {
				font-size: 12px;
				color: #646970;
			}
			.aeafe-status-badge {
				display: inline-flex;
				align-items: center;
				gap: 6px;
				padding: 4px 10px;
				border-radius: 20px;
				font-size: 12px;
				font-weight: 600;
			}
			.aeafe-status-badge .status-dot {
				width: 8px;
				height: 8px;
				border-radius: 50%;
			}
			.status-connected {
				background: #ecfdf3;
				color: #027a48;
			}
			.status-connected .status-dot {
				background: #12b76a;
				box-shadow: 0 0 0 3px rgba(18, 183, 106, 0.2);
			}
			.status-ready {
				background: #eff8ff;
				color: #175cd3;
			}
			.status-ready .status-dot {
				background: #2e90fa;
				box-shadow: 0 0 0 3px rgba(46, 144, 250, 0.2);
			}
			.status-unconfigured {
				background: #fff6ed;
				color: #c4320a;
			}
			.status-unconfigured .status-dot {
				background: #f79009;
				box-shadow: 0 0 0 3px rgba(247, 144, 9, 0.2);
			}
			.aeafe-card-body {
				padding: 24px;
			}
			.aeafe-form-group {
				margin-bottom: 20px;
			}
			.aeafe-label {
				display: block;
				font-size: 13px;
				font-weight: 600;
				color: #1d2327;
				margin-bottom: 6px;
			}
			.aeafe-label .required {
				color: #d63638;
			}
			.aeafe-field-help {
				font-size: 12px;
				color: #646970;
				margin: 0 0 8px 0;
			}
			.aeafe-copy-box {
				display: flex;
				gap: 8px;
			}
			.aeafe-readonly-input {
				flex: 1;
				background: #f6f7f7 !important;
				color: #2c3338 !important;
				font-family: monospace;
				font-size: 12px;
				border: 1px solid #dcdcde;
				border-radius: 4px;
				padding: 6px 10px;
			}
			.aeafe-input-full {
				width: 100% !important;
				border: 1px solid #dcdcde;
				border-radius: 4px;
				padding: 8px 12px;
				font-size: 13px;
			}
			.aeafe-password-wrap {
				position: relative;
				display: flex;
				align-items: center;
			}
			.aeafe-password-wrap input {
				padding-right: 36px;
			}
			.aeafe-toggle-secret {
				position: absolute;
				right: 6px;
				background: none;
				border: none;
				color: #646970;
				cursor: pointer;
				padding: 4px;
			}
			.aeafe-toggle-secret:hover {
				color: #1d2327;
			}
			.aeafe-form-actions {
				display: flex;
				flex-wrap: wrap;
				align-items: center;
				gap: 12px;
				padding-top: 10px;
				border-top: 1px solid #f0f0f1;
				margin-top: 24px;
			}
			.aeafe-btn-danger {
				color: #d63638 !important;
				border-color: #d63638 !important;
			}
			.aeafe-btn-danger:hover {
				background: #d63638 !important;
				color: #fff !important;
			}
			.aeafe-btn-connect {
				background: #1a73e8 !important;
				border-color: #1a73e8 !important;
				color: #fff !important;
			}
			.aeafe-btn-connect:hover {
				background: #1558b0 !important;
				border-color: #1558b0 !important;
			}
			.aeafe-steps-list {
				margin: 0;
				padding-left: 20px;
				color: #2c3338;
				line-height: 1.6;
			}
			.aeafe-steps-list li {
				margin-bottom: 14px;
				font-size: 13px;
			}
			.aeafe-steps-list strong {
				display: block;
				color: #1d2327;
			}
			.aeafe-help-footer {
				margin-top: 20px;
				padding: 12px 16px;
				background: #f0f6fc;
				border-radius: 6px;
				border-left: 4px solid #2271b1;
			}
			.aeafe-help-footer p {
				margin: 0;
				font-size: 12px;
				color: #1e3a8a;
				display: flex;
				align-items: flex-start;
				gap: 8px;
			}
			</style>
			<?php
		}

		public function aeafeGetBlocks(){
			$nonce = sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) ?? null;

			if( !wp_verify_nonce( $nonce, 'bptb_admin_nonce' )){
				wp_send_json_error( 'Invalid Request' );
			}

			$data = json_decode( stripslashes( $_POST['data'] ), true );
			$db_data = get_option( 'aeafeGetBlocks', [] );

			if( !isset( $data ) && $db_data ){
				wp_send_json_success( $db_data );
			}

			update_option( 'aeafeGetBlocks', $data );
			wp_send_json_success( $data );

		}
	
		public function aeafeRenderDashboardPage(){ ?>
			<div
				id='mpafebDashboard'
				data-info='<?php echo esc_attr( wp_json_encode( [
					'version' => AEAFE_VERSION,
					'nonce' => wp_create_nonce( 'bptb_admin_nonce' ),
					// 'isPremium' => aeafeIsPremium(),
					'isPremium' => false,
					'hasPro' => false,
					'action' => 'bptbGetBlocks',
					'adminUrl' => admin_url(),
				] ) ); ?>'
			></div>
		<?php }
	
		function aeafeAdminEnqueueScripts( $hook ) {
			if( strpos( $hook, 'all-embed-addons-for-elementor' ) ){
				wp_enqueue_style( 'aeafe-admin-dashboard', AEAFE_DIR_URL . 'build/admin/dashboard.css', [], AEAFE_VERSION );
				wp_enqueue_script( 'aeafe-admin-dashboard', AEAFE_DIR_URL . 'build/admin/dashboard.js', [ 'react', 'react-dom','wp-util' ], AEAFE_VERSION, true );
				wp_set_script_translations( 'aeafe-admin-dashboard', 'media-player-addons-for-elementor', AEAFE_DIR_PATH . 'languages' );
			}
		}
	}
	new AEAFEAdminMenu();
}
